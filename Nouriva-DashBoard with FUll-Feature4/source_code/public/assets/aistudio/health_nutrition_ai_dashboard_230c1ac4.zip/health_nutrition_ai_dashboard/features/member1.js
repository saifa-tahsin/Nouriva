// Feature module 1 initialization
console.log('Member module 1 loaded');