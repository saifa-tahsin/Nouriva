// Feature module 2 initialization
console.log('Member module 2 loaded');