# Nouriva — Team Dashboard

A responsive HTML, CSS, and JavaScript starter dashboard for the team's four assigned features.

## Open the dashboard
1. Extract `Nouriva-Dashboard.zip`.
2. Open `index.html` in a browser.
3. Keep the `assets`, `features`, `index.html`, `style.css`, and `script.js` paths together.

## Team feature files
- `features/member1.js` — AI Food & Health Scanner
- `features/member2.js` — Personalized AI Nutrition Coach
- `features/member3.js` — Budget-Aware AI Meal Planner
- `features/member4.js` — Daily Nutrition Tracker + Conversational AI Food Assistant

These files are intentionally empty placeholders. Each member can add their own feature code to the assigned file. The dashboard is a UI starter and does not yet connect the four features or any AI/nutrition API.

## Suggested GitHub workflow
1. One teammate creates a repository and uploads the extracted project folder.
2. Share the repository with the other members.
3. Each member edits their assigned file, commits, and pushes their changes (or creates a branch and pull request).
4. Integrate and test together before the demo.

## Important notes
- The dashboard uses local image assets stored in `assets/`.
- Google Fonts is an optional external font import; the page still falls back to system fonts if unavailable.
- Nutrition values, food-price data, AI chat, image recognition, OCR, and medical advice are not implemented in this starter shell.
- Nutrition guidance should remain general and should not diagnose or treat medical conditions.
