// Small interactions for the shared dashboard shell.
// Feature implementations belong in features/member1.js ... features/member4.js.
document.querySelectorAll('.nav-link').forEach((link) => {
  link.addEventListener('click', () => {
    document.querySelectorAll('.nav-link').forEach((item) => item.classList.remove('active'));
    link.classList.add('active');
  });
});

// The four member files are intentionally placeholders for team contributions.
console.info('Health & Nutrition AI dashboard loaded.');


// Expand or collapse the details for each feature card.
document.querySelectorAll('.feature-toggle').forEach((button) => {
  button.addEventListener('click', () => {
    const details = button.nextElementSibling;
    const isOpen = button.getAttribute('aria-expanded') === 'true';
    button.setAttribute('aria-expanded', String(!isOpen));
    details.hidden = isOpen;
    const marker = button.querySelector('span');
    if (marker) marker.textContent = isOpen ? '＋' : '−';
  });
});
